"""
兼容保留：旧路径 rules/single/cnt_newcycles.py 已迁移至 rules/kpi/cnt_newcycles.py。
为避免引用报错，这里仅做转发，不再包含具体逻辑。
"""

from rules.kpi.cnt_newcycles import CONFIG, get_logic_rules  # noqa: F401